﻿using Ejercicios_Prueba.Models;
using Ejercicios_Prueba.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrosDesktop.View
{
    public partial class AgregarEditarLibroView : Form
    {
        private string idLibroSeleccionado;
        LibrosRepository repo = new LibrosRepository();


        //Constructor
        public AgregarEditarLibroView()
        {
            InitializeComponent();
        }


        //Constructo que recibe id como parametro
        public AgregarEditarLibroView(string idLibroSeleccionado)
        {
            this.idLibroSeleccionado = idLibroSeleccionado;
            InitializeComponent();
            CargarDatosLibroEnPantalla();
        }

        private async void CargarDatosLibroEnPantalla()
        {

            Libro? libro = await repo.ObtenerPorIdAsync(this.idLibroSeleccionado);
            if (libro != null)
            {

                textNombre.Text = libro.nombre;
                textAutor.Text = libro.autor;
                textEditorial.Text = libro.editorial;
                textPortadaUrl.Text = libro.portada_url;
                textGenero.Text = libro.genero;
                textSinopsis.Text = libro.sinopsis;
                numericPaginas.Value = libro.paginas;
                pictureBoxPortada.ImageLocation = libro.portada_url;
            }
            else
            {
                MessageBox.Show("Error no se encontro el libro");
            }

        }



        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            LibrosRepository repo = new LibrosRepository();

            if (this.idLibroSeleccionado != null)
            {
                await repo.ActualizarAsync(
                            textNombre.Text,
                            textAutor.Text,
                            (int)numericPaginas.Value,
                            textEditorial.Text,
                            textPortadaUrl.Text,
                            textSinopsis.Text,
                            textGenero.Text,
                            this.idLibroSeleccionado);
                this.Close();
            }
            else
            {
                await repo.AgregarAsync(
                            textNombre.Text,
                            textAutor.Text,
                            (int)numericPaginas.Value,
                            textEditorial.Text,
                            textPortadaUrl.Text,
                            textSinopsis.Text,
                            textGenero.Text);
                this.Close();
            }


        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
