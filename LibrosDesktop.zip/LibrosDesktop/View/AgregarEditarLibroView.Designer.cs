﻿namespace LibrosDesktop.View
{
    partial class AgregarEditarLibroView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCancelar = new Button();
            btnGuardar = new Button();
            textGenero = new TextBox();
            label7 = new Label();
            numericPaginas = new NumericUpDown();
            textPaginas = new Label();
            textSinopsis = new TextBox();
            textPortadaUrl = new TextBox();
            textEditorial = new TextBox();
            textAutor = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            textNombre = new TextBox();
            label1 = new Label();
            pictureBoxPortada = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)numericPaginas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPortada).BeginInit();
            SuspendLayout();
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(396, 552);
            btnCancelar.Margin = new Padding(3, 2, 3, 2);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(82, 22);
            btnCancelar.TabIndex = 31;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(255, 552);
            btnGuardar.Margin = new Padding(3, 2, 3, 2);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(82, 22);
            btnGuardar.TabIndex = 30;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // textGenero
            // 
            textGenero.Location = new Point(171, 462);
            textGenero.Margin = new Padding(3, 2, 3, 2);
            textGenero.Name = "textGenero";
            textGenero.Size = new Size(472, 23);
            textGenero.TabIndex = 29;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(94, 462);
            label7.Name = "label7";
            label7.Size = new Size(48, 15);
            label7.TabIndex = 28;
            label7.Text = "Genero:";
            // 
            // numericPaginas
            // 
            numericPaginas.Location = new Point(171, 418);
            numericPaginas.Margin = new Padding(3, 2, 3, 2);
            numericPaginas.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numericPaginas.Name = "numericPaginas";
            numericPaginas.Size = new Size(131, 23);
            numericPaginas.TabIndex = 27;
            numericPaginas.TextAlign = HorizontalAlignment.Right;
            // 
            // textPaginas
            // 
            textPaginas.AutoSize = true;
            textPaginas.Location = new Point(91, 419);
            textPaginas.Name = "textPaginas";
            textPaginas.Size = new Size(51, 15);
            textPaginas.TabIndex = 26;
            textPaginas.Text = "Paginas:";
            // 
            // textSinopsis
            // 
            textSinopsis.Location = new Point(172, 338);
            textSinopsis.Margin = new Padding(3, 2, 3, 2);
            textSinopsis.Multiline = true;
            textSinopsis.Name = "textSinopsis";
            textSinopsis.Size = new Size(473, 62);
            textSinopsis.TabIndex = 25;
            // 
            // textPortadaUrl
            // 
            textPortadaUrl.Location = new Point(172, 142);
            textPortadaUrl.Margin = new Padding(3, 2, 3, 2);
            textPortadaUrl.Name = "textPortadaUrl";
            textPortadaUrl.Size = new Size(472, 23);
            textPortadaUrl.TabIndex = 24;
            // 
            // textEditorial
            // 
            textEditorial.Location = new Point(171, 103);
            textEditorial.Margin = new Padding(3, 2, 3, 2);
            textEditorial.Name = "textEditorial";
            textEditorial.Size = new Size(473, 23);
            textEditorial.TabIndex = 23;
            // 
            // textAutor
            // 
            textAutor.Location = new Point(172, 67);
            textAutor.Margin = new Padding(3, 2, 3, 2);
            textAutor.Name = "textAutor";
            textAutor.Size = new Size(473, 23);
            textAutor.TabIndex = 22;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(91, 338);
            label5.Name = "label5";
            label5.Size = new Size(53, 15);
            label5.TabIndex = 21;
            label5.Text = "Sinopsis:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(91, 142);
            label4.Name = "label4";
            label4.Size = new Size(69, 15);
            label4.TabIndex = 20;
            label4.Text = "Portada Url:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(91, 103);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 19;
            label3.Text = "Editorial";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(91, 67);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 18;
            label2.Text = "Autor:";
            // 
            // textNombre
            // 
            textNombre.Location = new Point(172, 31);
            textNombre.Margin = new Padding(3, 2, 3, 2);
            textNombre.Name = "textNombre";
            textNombre.Size = new Size(473, 23);
            textNombre.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(91, 31);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 16;
            label1.Text = "Nombre:";
            // 
            // pictureBoxPortada
            // 
            pictureBoxPortada.Location = new Point(265, 170);
            pictureBoxPortada.Name = "pictureBoxPortada";
            pictureBoxPortada.Size = new Size(262, 163);
            pictureBoxPortada.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxPortada.TabIndex = 32;
            pictureBoxPortada.TabStop = false;
            // 
            // AgregarEditarLibroView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 581);
            Controls.Add(pictureBoxPortada);
            Controls.Add(btnCancelar);
            Controls.Add(btnGuardar);
            Controls.Add(textGenero);
            Controls.Add(label7);
            Controls.Add(numericPaginas);
            Controls.Add(textPaginas);
            Controls.Add(textSinopsis);
            Controls.Add(textPortadaUrl);
            Controls.Add(textEditorial);
            Controls.Add(textAutor);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textNombre);
            Controls.Add(label1);
            Name = "AgregarEditarLibroView";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Agregar/Editar Libros";
            ((System.ComponentModel.ISupportInitialize)numericPaginas).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPortada).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCancelar;
        private Button btnGuardar;
        private TextBox textGenero;
        private Label label7;
        private NumericUpDown numericPaginas;
        private Label textPaginas;
        private TextBox textSinopsis;
        private TextBox textPortadaUrl;
        private TextBox textEditorial;
        private TextBox textAutor;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textNombre;
        private Label label1;
        private PictureBox pictureBoxPortada;
    }
}