﻿using Ejercicios_Prueba.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTesteoLibros
{
    internal class TestPersonajes
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task TestObtenerPersonajes()
        {
            PersonajesRepository personajesRepository = new PersonajesRepository();
            var personajes = await personajesRepository.ObtenerPersonajesAsync();

            Assert.That(personajes.Count, Is.Not.EqualTo(0));
        }

        [Test]
        public async Task TestAgregarPersonaje()
        {
            PersonajesRepository personajesRepository = new PersonajesRepository();
            var personaje = await personajesRepository.AgregarAsync(
                "Jeor Mormont",
                69,
                "El Viejo Oso",
                "https://static.wikia.nocookie.net/hieloyfuego/images/f/f2/Jeor_mormont.JPG/revision/latest?cb=20221102130419",
                "Mormont");
        }
        [Test]
        public async Task TestEliminarPersonaje()
        {
            PersonajesRepository personajesRepository = new PersonajesRepository();
            var borrado = await personajesRepository.EliminarAsync("665f423623cd5f4600003701");
            Assert.That(borrado, Is.EqualTo(true));
        }

        [Test]
        public async Task TestActualizarLibro()
        {
            PersonajesRepository personajesRepository = new PersonajesRepository();
            var personaje = await personajesRepository.ActualizarAsync("", 100, "EditorialTest2", "SinopsisTest2", "PortadaURLTest2", "");
            Assert.That(personaje.Nombre_completo, Is.EqualTo(""));
        }
    }
}
