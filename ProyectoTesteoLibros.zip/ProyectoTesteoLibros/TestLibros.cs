using Newtonsoft.Json;
using System.Text;
using System;
using Ejercicios_Prueba.Repositories;
using Ejercicios_Prueba.Models;

namespace ProyectoTesteoLibros
{
    public class TestLibros
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task TestObtenerLibros()
        {
            LibrosRepository librosRepository = new LibrosRepository();
            var libros = await librosRepository.ObtenerLibrosAsync();

            Assert.That(libros.Count, Is.Not.EqualTo(0));
        }

        [Test]
        public async Task TestAgregarLibro()
        {
            LibrosRepository librosRepository = new LibrosRepository();
            var libro = await librosRepository.AgregarAsync("Game of Thrones - Canci�n de hielo y fuego", "George R.R. Martin", 800, "Debolsillo", "En el legendario mundo de los Siete Reinos, donde el verano puede durar d�cadas y el invierno toda una vida, y donde rastros de una magia inmemorial surgen en los rincones m�s sombr�os, la tierra del norte, Invernalia, est� resguardada por un colosal muro de hielo que detiene a fuerzas oscuras y sobrenaturales.", "https://m.media-amazon.com/images/I/61royjw7ITL._SY425_.jpg", "Fantas�a �pica");
            Assert.That(libro.nombre, Is.EqualTo("Game of Thrones - Canci�n de hielo y fuego"));
            Assert.That(libro.autor, Is.EqualTo("George R.R. Martin"));
            Assert.That(libro.paginas, Is.EqualTo(800));
            Assert.That(libro.editorial, Is.EqualTo("Debolsillo"));
            Assert.That(libro.sinopsis, Is.EqualTo("En el legendario mundo de los Siete Reinos, donde el verano puede durar d�cadas y el invierno toda una vida, y donde rastros de una magia inmemorial surgen en los rincones m�s sombr�os, la tierra del norte, Invernalia, est� resguardada por un colosal muro de hielo que detiene a fuerzas oscuras y sobrenaturales."));
            Assert.That(libro.portada_url, Is.EqualTo("https://m.media-amazon.com/images/I/61royjw7ITL._SY425_.jpg"));
            Assert.That(libro.genero, Is.EqualTo("Fantas�a �pica"));

        }
        [Test]
        public async Task TestEliminarLibro()
        {
            LibrosRepository librosRepository = new LibrosRepository();
            var borrado = await librosRepository.EliminarAsync("665f423623cd5f4600003701");
            Assert.That(borrado, Is.EqualTo(true));
        }
        [Test]
        public async Task TestObtenerLibro()
        {
            LibrosRepository librosRepository = new LibrosRepository();
            var libro = await librosRepository.ObtenerPorIdAsync("6657ee85ea2ecd6500019759");
            Assert.That(libro.nombre, Is.EqualTo("El se�or de los anillos-La Comunidad Del Anillo"));
        }
        [Test]
        public async Task TestActualizarLibro()
        {
            LibrosRepository librosRepository = new LibrosRepository();
            var libro = await librosRepository.ActualizarAsync("LibroTest2Actualizado", "autoTest2", 100, "EditorialTest2", "SinopsisTest2", "PortadaURLTest2", "GeneroURL2", "665e45aa23cd5f4600002c85");
            Assert.That(libro.nombre, Is.EqualTo("LibroTest2Actualizado"));
        }
    }
}